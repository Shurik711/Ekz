﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kval
{
    class Class1
    {

        public static EXFDEntities1 db = new EXFDEntities1();
        public static string id_cat;
        public static string pas;
    }
}
