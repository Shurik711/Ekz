﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kval
{
    class Class1
    {

        public static ZadEntities db = new ZadEntities();
        public static int id_cat;
        public static string pas;
    }
}
