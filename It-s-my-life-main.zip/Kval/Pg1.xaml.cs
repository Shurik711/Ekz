﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kval
{
    /// <summary>
    /// Логика взаимодействия для Pg1.xaml
    /// </summary>
    public partial class Pg1 : Page
    {
        public Pg1()
        {
            InitializeComponent();
            LB2.ItemsSource = Class1.db.Товары.Where(x => x.КатегорияТовараID == Class1.id_cat).ToList();
                
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            var c1 = LB2.SelectedItem as Товары;
            Random rd = new Random();
            Class1.db.Заказы.Add(new Заказы {ДатаЗаказа = new DateTime(), НомерЗаказа = Convert.ToString (rd.Next(1, 99)), СтатусЗаказаID = 0, ТоварID = c1.ID});
            Class1.db.SaveChanges();
           
        }
    }
}
