﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kval
{
    /// <summary>
    /// Логика взаимодействия для W2.xaml
    /// </summary>
    public partial class W2 : Window
    {
        public W2()
        {
            InitializeComponent();
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            string s0, st, s1;
            s0 = "";
            Random rnd = new Random();
            int n;
            st = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            for (int j = 0; j < 9; j++)
            {
                n = rnd.Next(0, 61);
                s1 = st.Substring(n, 1);
                s0 += s1;

            }
            pb1.Password = s0;
        }

        private void B2_Click(object sender, RoutedEventArgs e)
            {
            
                if (tb1.Text == "Менеджер" && pb1.Password == "54321")
                { 
                W4 win = new W4();
                win.Show();
                Close();
            }
            else
            {
                MessageBox.Show("Неправильный логин или пароль");
            }
        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win = new MainWindow();
            win.Show();
            Close();
        }
    }
}
