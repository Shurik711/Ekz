﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kval
{
    /// <summary>
    /// Логика взаимодействия для W4.xaml
    /// </summary>
    public partial class W4 : Window
    {
        public W4()
        {
            InitializeComponent();
            lb1.ItemsSource = Class1.db.Заказы.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win = new MainWindow();
            win.Show();
            Close();
        }

        private void TextBlock_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            var v1 = lb1.SelectedItem as Заказы;
            Class1.db.Заказы.Remove(v1);
            Class1.db.SaveChanges();
            lb1.ItemsSource = Class1.db.Заказы.ToList();
        }
    }
}
